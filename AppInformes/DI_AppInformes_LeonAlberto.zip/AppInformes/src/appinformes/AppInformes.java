/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appinformes;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Alberto Leon
 */
public class AppInformes extends Application
{

    @Override
    public void start(Stage primaryStage) throws IOException
    {
        //Creamos la escena 
        FXMLLoader fxmloader = new FXMLLoader(getClass().getResource("MenuBar.fxml"));
        Parent root = fxmloader.load();
        MenuBarController principal = (MenuBarController) fxmloader.getController();

        primaryStage.setResizable(false);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }



//    public void generaInforme(TextField tintro)
//    {
//        try
//        {
//            JasperReport jr = (JasperReport) JRLoader.loadObject(AppInformes.class.getResource("PedidosProd.jasper"));
//            //Map de parámetros 
//            Map parametros = new HashMap();
//            int nproducto = Integer.valueOf(tintro.getText());
//            parametros.put("ParamProducto", nproducto);
//            JasperPrint jp = (JasperPrint) JasperFillManager.fillReport(jr, parametros, conexion);
//            JasperViewer.viewReport(jp);
//        } catch (JRException ex)
//        {
//            System.out.println("Error al recuperar el jasper");
//            JOptionPane.showMessageDialog(null, ex);
//        }
//    }

    /**
     * * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        launch(args);
    }
}
